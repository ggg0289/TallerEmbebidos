<html>
    <head>
        <meta charset="utf-8" />
        <title>Proyecto-Embebidos</title>
    </head>
 
    <body style="background-color: white;">
	<center>
	<img height="480" width = "640" src="http://192.168.43.25:806
0/stream.mjpg" />
	<br>
	<button id="myP" onmousedown="mouseDown(02)" onmouseup="mouseUp(02)">Atras</button>
	<button id="myP" onmousedown="mouseDown(03)" onmouseup="mouseUp(03)">Derecha</button>
	<button id="myP" onmousedown="mouseDown(34)" onmouseup="mouseUp(34)">Adelante</button>
	<button id="myP" onmousedown="mouseDown(24)" onmouseup="mouseUp(24)">Izquierda</button>
	<br>
	<br>
	<button id="myP" onmousedown="mouseDown(04)" onmouseup="mouseUp(04)">Led On</button>
	<button id="myP" onmousedown="mouseDown(07)" onmouseup="mouseUp(07)">Led Off</button>
	<br>
	<br>
<!------------------------------------------------ php -->
<?php
	//Define los pines GPIO0, GPIO 2, GPIO3, GPIO4 en modo salida		
	system("gpio mode 0 out");
	system("gpio write 0 0");
	system("gpio mode 2 out");
	system("gpio write 2 0");
	system("gpio mode 3 out");
	system("gpio write 3 0");
	system("gpio mode 4 out");
	system("gpio write 4 0");

	system("gpio mode 5 out");
	system("gpio write 5 0");

	//-----Actualizacion del boton de estado
	$output = shell_exec("cat temp");
	if ($output ==0) {
		echo ("<img id='status' height=48 width = 120 src='data/ON.png'/>");
	}
	else {
		echo ("<img id='status' height=48 width = 120 src='data/OFF.png'/>");
	}	
?>

	</center>
	 
<!------------------------------------------------ javascript -->
<script src="camara.js"></script>

    </body>
</html>



